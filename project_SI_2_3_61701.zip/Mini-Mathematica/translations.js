angular.module('gettext').run(['gettextCatalog', function (gettextCatalog) {
/* jshint -W100 */
    gettextCatalog.setStrings('bg', {"Bootstrap starter template":"Добре долши!"});
/* jshint +W100 */
}]);