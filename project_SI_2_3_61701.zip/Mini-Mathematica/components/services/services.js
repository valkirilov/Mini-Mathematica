'use strict';

angular.module('myApp.services', [
  'myApp.services.calc',
]);